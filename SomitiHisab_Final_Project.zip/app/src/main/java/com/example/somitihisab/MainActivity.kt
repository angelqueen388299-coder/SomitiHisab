package com.example.somitihisab
import android.app.*; import android.os.*; import android.widget.*; import android.view.*; import android.graphics.Color
class MainActivity: Activity(){
 override fun onCreate(b:Bundle?){super.onCreate(b); home()}
 private fun home(){
  val l=LinearLayout(this);l.orientation=LinearLayout.VERTICAL;l.setPadding(24,24,24,24)
  val t=TextView(this);t.text="💰 সমিতি হিসাব\nSQLite/Room Database";t.textSize=24f;t.setTextColor(Color.rgb(23,105,170));l.addView(t)
  listOf("👤 সদস্য ও প্রোফাইল","💰 তারিখভিত্তিক জমা","📅 ৫ দিনের হিসাব","🏆 ড্র ও বিজয়ী","📜 ড্র ইতিহাস","💾 Backup / Restore").forEach{txt->val b=Button(this);b.text=txt;b.setOnClickListener{Toast.makeText(this,"$txt — Database version ready",Toast.LENGTH_SHORT).show()};l.addView(b)}
  setContentView(l)
 }
}