এই ZIP-এ GitHub Actions workflow আছে।

ব্যবহার:
1. GitHub repository-তে .github/workflows/android-build.yml আপলোড করুন।
2. আপনার repository-র মূল জায়গায় SomitiHisab_Final_Project.zip থাকতে হবে।
3. Actions → Build SomitiHisab APK → Run workflow।
4. Build সফল হলে SomitiHisab-APK artifact থেকে app-debug.apk ডাউনলোড করুন।

নোট: workflow আপনার ZIP খুলে Gradle build করার চেষ্টা করবে এবং KAPT plugin-এর প্রয়োজনীয়তা ঠিক করবে।
